
<?php $__env->startSection('content'); ?>
        <h1>About</h1>
        <p>Ini Adalah Praktikum pemograman web yang mempelajari Framework PHP yaitu Laravel</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice_laravel\resources\views/about.blade.php ENDPATH**/ ?>