@extends('template.base')
@section('content')
        <h1>Beranda</h1>
        <p>Welcome to my page </p>
@endsection