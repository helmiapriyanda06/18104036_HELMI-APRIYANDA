
<?php $__env->startSection('content'); ?>
        <h1>Beranda</h1>
        <p>Welcome to my page </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\New folder\practice_laravel\resources\views/beranda.blade.php ENDPATH**/ ?>