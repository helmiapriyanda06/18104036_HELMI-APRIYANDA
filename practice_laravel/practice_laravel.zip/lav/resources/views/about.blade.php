@extends('template.base')
@section('content')
        <h1>About</h1>
        <p>Ini Adalah Praktikum pemograman web yang mempelajari Framework PHP yaitu Laravel</p>
@endsection